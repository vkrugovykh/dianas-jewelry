<h3>Перейдите по ссылке для активации подписки</h3>

<a href="http://dianas-jewelry.vkdev.ru/subscribe/activation?key=<?= $subscribe->activation_key ?>">http://dianas-jewelry/subscribe/activation?key=<?= $subscribe->activation_key ?></a>