<?php

return [
    'adminEmail' => 'vasickru@mail.ru',
];
